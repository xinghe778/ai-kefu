<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'api');
define('DB_USER', 'api');
define('DB_PASS', 'bW2TehrNw8PprGe8');