<?php
// 日志记录函数
function log_action($pdo, $action, $description = '', $user_id = null) {
    $stmt = $pdo->prepare("INSERT INTO logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)");
    
    $user_id = $user_id ?: ($_SESSION['user']['id'] ?? null);
    $ip = $_SERVER['REMOTE_ADDR'];
    
    $stmt->execute([
        $user_id,
        substr($action, 0, 255),
        $description,
        $ip
    ]);
}