<?php
require 'includes/db.php';
require 'includes/auth.php';

checkAuth();

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

if ($action === 'kb' && $method === 'POST') {
    // 处理知识库条目创建
    $data = json_decode(file_get_contents('php://input'), true);
    
    try {
        $kbId = addKbEntry($pdo, $data['title'], $data['content'], $data['category_id']);
        echo json_encode(['id' => $kbId, 'message' => '知识条目已创建']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// 其他知识库操作...