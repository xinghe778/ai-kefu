    </div>
    <footer style="text-align:center; padding: 20px; background: #ecf0f1; margin-top: 20px;">
        &copy; <?= date('Y') ?> 智能客服管理系统
    </footer>
</body>
</html>